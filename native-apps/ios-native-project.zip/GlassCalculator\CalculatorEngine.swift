import Foundation

struct CalculatorState: Equatable {
    private(set) var expression = "0"
    private(set) var justCalculated = false

    mutating func clear() {
        expression = "0"
        justCalculated = false
    }

    mutating func append(_ character: Character) {
        guard "0123456789.+-*/".contains(character) else { return }

        if expression == "Error" {
            expression = "0"
            justCalculated = false
        } else if justCalculated {
            if !"+-*/".contains(character) {
                expression = "0"
            }
            justCalculated = false
        }

        if "+-*/".contains(character) {
            if let last = expression.last, "+-*/".contains(last) {
                let hasUnaryMinus = expression.hasSuffix("-") &&
                    expression.count > 1 &&
                    "+-*/".contains(expression.dropLast().last ?? " ")
                if character == "-" && !hasUnaryMinus {
                    expression.append(character)
                    return
                }
                if hasUnaryMinus { expression.removeLast() }
                expression.removeLast()
            } else if expression == "0" && character != "-" {
                return
            }
            if expression.hasSuffix(".") { expression.append("0") }
            expression.append(character)
            return
        }

        if character == "." {
            let currentNumber = expression.split(whereSeparator: { "+-*/".contains($0) }).last ?? ""
            if currentNumber.contains(".") { return }
            if let last = expression.last, "+-*/".contains(last) {
                expression.append("0.")
            } else {
                expression.append(".")
            }
            return
        }

        if expression == "0" {
            expression = String(character)
        } else {
            expression.append(character)
        }
    }

    mutating func deleteLast() {
        if expression == "Error" || justCalculated {
            clear()
            return
        }
        if !expression.isEmpty { expression.removeLast() }
        if expression.isEmpty || expression == "-" { expression = "0" }
    }

    mutating func calculate() {
        do {
            var parser = try ExpressionParser(expression)
            let result = try parser.parse()
            guard result.isFinite else {
                expression = "Error"
                justCalculated = false
                return
            }
            var formatted = String(
                format: "%.10f",
                locale: Locale(identifier: "en_US_POSIX"),
                result
            )
            while formatted.contains(".") && formatted.last == "0" {
                formatted.removeLast()
            }
            if formatted.last == "." { formatted.removeLast() }
            expression = formatted
            justCalculated = true
        } catch {
            expression = "Error"
            justCalculated = false
        }
    }
}

private struct ExpressionParser {
    private let tokens: [String]
    private var position = 0

    init(_ expression: String) throws {
        tokens = try Self.tokenize(expression)
    }

    mutating func parse() throws -> Double {
        guard let last = tokens.last, !["+","-","*","/"].contains(last) else {
            throw CalculatorError.invalidExpression
        }
        let result = try parseExpression()
        guard position == tokens.count else {
            throw CalculatorError.invalidExpression
        }
        return result
    }

    private mutating func parseExpression() throws -> Double {
        var value = try parseTerm()
        while peek == "+" || peek == "-" {
            let operation = tokens[position]
            position += 1
            let right = try parseTerm()
            value = operation == "+" ? value + right : value - right
        }
        return value
    }

    private mutating func parseTerm() throws -> Double {
        var value = try parseFactor()
        while peek == "*" || peek == "/" {
            let operation = tokens[position]
            position += 1
            let right = try parseFactor()
            value = operation == "*" ? value * right : value / right
        }
        return value
    }

    private mutating func parseFactor() throws -> Double {
        if peek == "+" || peek == "-" {
            let sign = tokens[position] == "-" ? -1.0 : 1.0
            position += 1
            return sign * (try parseFactor())
        }
        guard position < tokens.count, let value = Double(tokens[position]) else {
            throw CalculatorError.invalidExpression
        }
        position += 1
        return value
    }

    private var peek: String? {
        position < tokens.count ? tokens[position] : nil
    }

    private static func tokenize(_ expression: String) throws -> [String] {
        let characters = Array(expression)
        var tokens: [String] = []
        var index = 0
        while index < characters.count {
            let character = characters[index]
            if character.isNumber || character == "." {
                let start = index
                var decimalPoints = 0
                while index < characters.count && (characters[index].isNumber || characters[index] == ".") {
                    if characters[index] == "." { decimalPoints += 1 }
                    index += 1
                }
                guard decimalPoints <= 1 else { throw CalculatorError.invalidExpression }
                let token = String(characters[start..<index])
                guard Double(token) != nil else { throw CalculatorError.invalidExpression }
                tokens.append(token)
            } else if "+-*/".contains(character) {
                tokens.append(String(character))
                index += 1
            } else {
                throw CalculatorError.invalidExpression
            }
        }
        return tokens
    }
}

private enum CalculatorError: Error {
    case invalidExpression
}
