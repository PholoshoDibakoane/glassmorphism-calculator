import SwiftUI

private enum KeyStyle: Equatable {
    case number
    case utility
    case operation

    var fill: Color {
        switch self {
        case .number: return Color.white.opacity(0.12)
        case .utility: return Color.white.opacity(0.25)
        case .operation: return Color(red: 1, green: 0.62, blue: 0.04).opacity(0.82)
        }
    }

    var foreground: Color {
        self == .utility ? .black : .white
    }
}

struct ContentView: View {
    @State private var calculator = CalculatorState()
    private let spacing: CGFloat = 12
    private let keyHeight: CGFloat = 60

    var body: some View {
        GeometryReader { geometry in
            let cardWidth = min(geometry.size.width - 32, 368)
            let keyWidth = (cardWidth - 48 - spacing * 3) / 4

            ScrollView {
                VStack(spacing: 0) {
                    display
                    VStack(spacing: spacing) {
                        keyRow(["AC", "÷", "×", "Del"], width: keyWidth)
                        keyRow(["7", "8", "9", "-"], width: keyWidth)
                        keyRow(["4", "5", "6", "+"], width: keyWidth)
                        HStack(alignment: .top, spacing: spacing) {
                            VStack(spacing: spacing) {
                                keyRow(["1", "2", "3"], width: keyWidth)
                                HStack(spacing: spacing) {
                                    button(for: "0")
                                        .frame(width: keyWidth * 2 + spacing, height: keyHeight)
                                    button(for: ".")
                                        .frame(width: keyWidth, height: keyHeight)
                                }
                            }
                            .frame(width: keyWidth * 3 + spacing * 2)
                            button(for: "=", height: keyHeight * 2 + spacing)
                                .frame(width: keyWidth, height: keyHeight * 2 + spacing)
                        }
                    }
                    .padding(.top, 20)
                }
                .padding(24)
                .frame(width: cardWidth)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 30))
                .overlay {
                    RoundedRectangle(cornerRadius: 30)
                        .fill(Color.white.opacity(0.08))
                        .allowsHitTesting(false)
                }
                .overlay {
                    RoundedRectangle(cornerRadius: 30)
                        .stroke(Color.white.opacity(0.12), lineWidth: 1)
                        .allowsHitTesting(false)
                }
                .shadow(color: .black.opacity(0.35), radius: 24, y: 14)
                .frame(maxWidth: .infinity, minHeight: geometry.size.height)
                .padding(.horizontal, 16)
                .padding(.vertical, 16)
            }
            .scrollIndicators(.hidden)
        }
        .background {
            LinearGradient(
                colors: [
                    Color(red: 0.06, green: 0.13, blue: 0.15),
                    Color(red: 0.13, green: 0.23, blue: 0.26),
                    Color(red: 0.17, green: 0.33, blue: 0.39)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
        }
        .preferredColorScheme(.dark)
    }

    private var display: some View {
        HStack {
            Spacer(minLength: 0)
            Text(calculator.expression)
                .font(.system(size: 40, weight: .light, design: .rounded))
                .lineLimit(1)
                .minimumScaleFactor(0.35)
                .contentTransition(.numericText())
                .accessibilityIdentifier("calculatorDisplay")
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 15)
        .padding(.vertical, 20)
        .background(Color.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 16))
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.white.opacity(0.08), lineWidth: 1)
        }
    }

    private func keyRow(_ labels: [String], width: CGFloat) -> some View {
        HStack(spacing: spacing) {
            ForEach(labels, id: \.self) { label in
                button(for: label)
                    .frame(width: width, height: keyHeight)
            }
        }
    }

    private func button(for label: String, height: CGFloat = 60) -> some View {
        let style: KeyStyle
        switch label {
        case "AC", "Del": style = .utility
        case "+", "-", "×", "÷", "=": style = .operation
        default: style = .number
        }
        return key(label, style: style, height: height) {
            switch label {
            case "AC": calculator.clear()
            case "Del": calculator.deleteLast()
            case "+": calculator.append("+")
            case "-": calculator.append("-")
            case "×": calculator.append("*")
            case "÷": calculator.append("/")
            case "=": calculator.calculate()
            default:
                if let character = label.first { calculator.append(character) }
            }
        }
    }

    private func key(
        _ label: String,
        style: KeyStyle,
        height: CGFloat = 60,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Text(label)
                .font(.system(size: 22, weight: style == .utility ? .medium : .regular))
                .lineLimit(1)
                .minimumScaleFactor(0.7)
                .foregroundStyle(style.foreground)
                .frame(maxWidth: .infinity)
                .frame(height: height)
                .background(style.fill, in: Capsule())
                .overlay {
                    Capsule()
                        .stroke(Color.white.opacity(0.18), lineWidth: 1)
                }
                .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(accessibleLabel(for: label))
    }

    private func accessibleLabel(for label: String) -> String {
        switch label {
        case "AC": return "Clear"
        case "Del": return "Delete last digit"
        case "÷": return "Divide"
        case "×": return "Multiply"
        case "=": return "Equals"
        default: return label
        }
    }
}

#Preview {
    ContentView()
}
